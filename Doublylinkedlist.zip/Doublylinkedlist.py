class Node:
    def __init__(self , data = None):
        self.data = data
        self.next = None
        self.prev = None

class DoublyLinkedList:
    def __init__(self , data = None):
        self.head = None
        self.tail = None
        self.size = 0

    def insertAtBegin(self , data):
        node = Node(data)

        if self.head is None:
            self.head = node
            self.tail = self.head
        else:
            node.next = self.head
            self.head.prev = node
            self.head = node
            self.size+=1
            
    def insertAtEnd(self , data):
        node = Node(data)

        if self.tail is None:
            self.tail = node
            self.head = self.tail
        else:
            self.tail.next = node
            node.prev = self.tail
            self.tail = node
            self.size+=1

    def insertAtPosition(self ,data , index):
        node = Node(data)

        if index < 1:
            print("Invalid indexing position")
        elif index == 1:
            self.insertAtBegin(data)
        elif index == self.size+1:
            self.insertAtEnd(data)
        elif index > self.size+1:
            print("Out of bound indexing position.")
        else:
            count = 1
            temp = self.head
            while count < index-1:
                temp = temp.next
                count+=1
            node.next = temp.next
            node.prev = temp
            temp.next.prev = node
            temp.next = node
            self.size+=1
        

    def insertBeforeElement(self , data , key):
        node = Node(key)
        temp = self.head
        prev = self.head

        if (temp.data == data):
            self.insertAtBegin(key)
        else:
            while temp.data != data and temp.next is not None:
                prev = temp
                temp = temp.next

            node.next = temp
            node.prev = prev
            temp.prev = node
            prev.next = node
            self.size+=1
            
    def insertafterElement(self , data , key):
        node = Node(key)
        temp = self.head
        while temp.data!= data and temp.next is not None:
            temp = temp.next

        if temp.next is None:
            if temp.data == data:
                self.insertAtEnd(key)
            else:
                print(f"{data} is not present.")
        else:
            node.next = temp.next
            node.prev = temp
            temp.next.prev = node
            temp.next = node
            self.size+=1

    def display(self):
        if self.head is None:
            print("There are no elements present in the Doubly Linked list.")
        else:
            choice = int(input("Enter 1 to print from head: \n Enter 2 to print from tail:"))
            match choice:
                case 1:
                    temp = self.head
                    while temp is not None:
                        print(temp.data,end=" ")
                        temp = temp.next
                    print()
                case 2:
                    temp = self.tail
                    while temp:
                        print(temp.data,end=" ")
                        temp = temp.prev
                    print()

    def search(self , key):
        temp = self.head

        while temp:
             if temp.data == key:
                 print(f"The data {data} is present at position {count}")
                 return
             temp = temp.next
        print(f"{data} is not present in the Linked List")
        
    def deleteFromStart(self):
        if self.head is None:
            print("There is no element")
        else:
            self.head.next.prev = None
            self.head = self.head.next

    def deleteTheLast(self):
        if self.tail is None:
            print("There is no element")
        else:
            self.tail.prev.next = None
            self.tail = self.tail.prev

    def deleteAtPosition(self , position):
        if self.head is None:
            print("There is no element in the linked list")
        else:
            temp = self.head
            prev = self.head
            count = 1
            while count < position:
                count += 1
                prev = temp
                temp = temp.next
            temp.next.prev = prev
            prev.next = temp.next


w =  DoublyLinkedList()

while True:
    print("1> insert at begining")
    print("2> insert at end")
    print("3> insert at position")
    print("4> insert before an element")
    print("5> insert after an element")
    print("6> for display")
    print("7> for search" )
    print("8>delete from first")
    print("9>delete from last")
    print("10>delete at a position")
    print("11> to exit the program")


    choice = int(input("Enter your choice: "))

    match choice:
        case 1:
            data = int(input("enter the data : "))
            w.insertAtBegin(data)
        case 2:
            data = int(input("enter the data : "))
            w.insertAtEnd(data)
        case 3:
            data = int(input("enter the data : "))
            position = int(input("Enter the position: "))
            w.insertAtPosition(data , position)
        case 4:
            data = int(input("enter the data : "))
            element = int(input("Enter before the element: "))
            w.insertBeforeElement(element , data)
        case 5:
            data = int(input("enter the data : "))
            element = int(input("Enter after the element: "))
            w.insertafterElement(element , data)
        case 6:
            w.display()
        case 7:
            data = int(input("Enter the element to search : "))
            w.search(data)
        case 8:
            w.deleteFromStart()
        case 9:
            w.deleteTheLast()
        case 10:
            position = int(input("Enter the position: "))
            w.deleteAtPosition(position)
        case 11:
            print("Exiting the program...")
            break
        
        





















